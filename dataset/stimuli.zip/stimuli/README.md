This folder contains two subfolders: "left-hand-motor-imagery" and "right-hand-motor-imagery".

In left-hand-motor-imagery folder：
	stim1.png: Pre-preparation instruction 2s
	stim2.mp4: Left-hand motor imagery stimuli material   4s
	stim3.png: Break   2s
	
In right-hand-motor-imagery folder：
	stim1.png: Pre-preparation instruction 2s
	stim2.mp4: Right-hand motor imagery stimuli material   4s
	stim3.png: Break   2s